using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enums{
    public enum highlight{
        None = 0, Move = 1, Damage = 2, Control = 3, Selected = 4
    }
    public enum Enemy{
        None, Rat, Pigeon, Boar, Raccoon, Falcon, Character, Custom
    }

    
}
